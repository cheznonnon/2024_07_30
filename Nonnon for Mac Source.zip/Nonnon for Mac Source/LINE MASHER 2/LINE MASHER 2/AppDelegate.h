//
//  AppDelegate.h
//  LINE MASHER 2
//
//  Created by のんのん on 2023/01/31.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

